package com.saeyan.dao;

public class MemberDAO {

}
