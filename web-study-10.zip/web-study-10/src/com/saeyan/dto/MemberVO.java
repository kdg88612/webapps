package com.saeyan.dto;

public class MemberVO {

}
